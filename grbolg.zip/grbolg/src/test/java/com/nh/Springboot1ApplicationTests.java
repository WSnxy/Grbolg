package com.nh;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.nh.dao.ArticleContentDao;
import com.nh.dao.ArticleInfoDao;
import com.nh.dao.ArticleTypeDao;
import com.nh.dao.RoleDao;
import com.nh.dao.UserBao;
import com.nh.pojo.ArticleInfo;
import com.nh.pojo.ArticleType;
import com.nh.pojo.Role;
import com.nh.pojo.User;

@SpringBootTest
class Springboot1ApplicationTests {
	@Autowired
	 ArticleContentDao  articleContentDao;
	
	@Autowired
	ArticleInfoDao  articleInfoDao;
	
	@Autowired
	ArticleTypeDao  articleTypeDao;
	
	@Autowired
	UserBao userBao;
	
	@Autowired
	RoleDao roleBao;
	
	
	@Test
	void contextLoads() {
		ArticleType type = new ArticleType();
		type.setType("Java");
		articleTypeDao.save(type);
	}
	
	@Test
	void addArticleInfo() {
		 ArticleInfo articleInfo = new ArticleInfo();
		 articleInfo.setUserId("ninghao");
		 articleInfo.setTitle("Java后端");
		 articleInfo.setThumbs(100);
		 articleInfo.setStaus(true);
		 articleInfo.setImage("http://");
		 articleInfo.setFirstLine("学习笔记");
		 articleInfo.setCreateTime(new Date());
		 articleInfo.setBrowseCount(1000);
		 articleInfoDao.save(articleInfo);
	}
	
	@Test
	void addManyToManyArticleType() {
		 ArticleType articleType = articleTypeDao.findById(1).get();
		List<ArticleType> articleTypes=new ArrayList<>();
		articleTypes.add(articleType);
		ArticleInfo articleInfo = articleInfoDao.findById("8a8688a66dec3458016dec345f750000").get();
		articleInfo.setArticleTypes(articleTypes);
		articleInfoDao.save(articleInfo);
	}
	@Test
	void readManyToManyArticleType() {
		ArticleInfo articleInfo = articleInfoDao.findById("8a8688a66dec3458016dec345f750000").get();
		List<ArticleType> articleTypes = articleInfo.getArticleTypes();
        for (ArticleType articleType : articleTypes) {
			System.out.println(articleType.getType());
		}
	}
	 @Test
     void addRole() {
		 Role role = new Role();
		 role.setRole("role_admin");
		 roleBao.save(role);
     }
	 @Test
	 void addUser() {
		 Role role = roleBao.findById(1).get();
		 User user = new User();
		 String encode = new BCryptPasswordEncoder().encode("123456");
		 user.setPassword(encode);
		 user.setUsername("ninghao");
		 ArrayList<Role> arrayList = new ArrayList<Role>();
		 arrayList.add(role);
		 user.setRoles(arrayList);
		 userBao.save(user);
	 }

}
